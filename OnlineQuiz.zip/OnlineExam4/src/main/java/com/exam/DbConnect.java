package com.exam;

import java.sql.*;


public class DbConnect {

    public static Connection getDataBaseConnection() throws SQLException {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("driver not found" + ex);
        }
        Connection connection = null;
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/online_exam", "root" , "root");
        return  connection;
    }

}
