package com.exam.dao;

import com.exam.DbConnect;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ShowQuestionDao {
    public ArrayList<String> getAllQuestionDetailsFromDB(String questionSetId) throws SQLException {
        ArrayList<String> questionsetList = new ArrayList<>();
        int questionsetCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT question_details FROM question INNER JOIN question_set WHERE question_set.question_id=question.question_id AND question_set.question_set_id="+questionSetId+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String name = resultSet.getString("question_details");
            questionsetList.add(name);

        }
        return  questionsetList;
    }

    public ArrayList<String> getAllOption1FromDb(String questionSetId) throws SQLException {
        ArrayList<String> questionsetList = new ArrayList<>();
        int questionsetCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT option_1 FROM options INNER JOIN question_set WHERE question_set.question_id=options.question_id AND question_set.question_set_id="+questionSetId+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String name = resultSet.getString("option_1");
            questionsetList.add(name);

        }
        return  questionsetList;
    }

    public ArrayList<String> getAllOption2FromDb(String questionSetId) throws SQLException {
        ArrayList<String> questionsetList = new ArrayList<>();
        int questionsetCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT option_2 FROM options INNER JOIN question_set WHERE question_set.question_id=options.question_id AND question_set.question_set_id="+questionSetId+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String name = resultSet.getString("option_2");
            questionsetList.add(name);

        }
        return  questionsetList;
    }

    public ArrayList<String> getAllOption3FromDb(String questionSetId) throws SQLException {
        ArrayList<String> questionsetList = new ArrayList<>();
        int questionsetCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT option_3 FROM options INNER JOIN question_set WHERE question_set.question_id=options.question_id AND question_set.question_set_id="+questionSetId+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String name = resultSet.getString("option_3");
            questionsetList.add(name);

        }
        return  questionsetList;
    }

    public ArrayList<String> getAllOption4FromDb(String questionSetId) throws SQLException {
        ArrayList<String> questionsetList = new ArrayList<>();
        int questionsetCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT option_4 FROM options INNER JOIN question_set WHERE question_set.question_id=options.question_id AND question_set.question_set_id="+questionSetId+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String name = resultSet.getString("option_4");
            questionsetList.add(name);

        }
        return  questionsetList;
    }

    public ArrayList<String> getAllQuestionIdFromDb(String questionSetId) throws SQLException {
        ArrayList<String> questionsetList = new ArrayList<>();
        int questionsetCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT question_id FROM question_set WHERE question_set.question_set_id="+questionSetId+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String id = resultSet.getString("question_id");
            questionsetList.add(id);

        }
        return  questionsetList;
    }
}
