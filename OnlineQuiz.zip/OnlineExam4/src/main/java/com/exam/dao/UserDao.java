package com.exam.dao;

import com.exam.DbConnect;

import java.sql.*;


public class UserDao {

    Statement myStmt = null;
    ResultSet myRs = null;

    String dbUserId;
    String dbPassword;

    public boolean searchUserByIdAndPass(String id, String pass) throws SQLException {

        boolean login = false;
        Connection connection = null;
        connection = DbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT * FROM user where user_id="+id+" and password='"+pass+"'";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while (resultSet.next()){
            System.out.println(resultSet.getRow());
            login = true;
        }

        return login;
    }

    public boolean searchUserById(String id) throws SQLException {

        boolean login = false;
        Connection connection = null;
        connection = DbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT * FROM user where user_id="+id+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while (resultSet.next()){
            System.out.println(resultSet.getRow());
            login = true;
        }

        return login;
    }

}
