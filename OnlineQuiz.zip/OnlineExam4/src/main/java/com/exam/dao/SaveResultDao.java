package com.exam.dao;

import com.exam.DbConnect;
import com.exam.Model.SaveResultObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SaveResultDao {
    public void saveResult(SaveResultObject saveResultObject) throws SQLException {
        Connection myConn = null;
        DbConnect dbConnect = new DbConnect();
        myConn = dbConnect.getDataBaseConnection();
        String insertSQL = "insert into result(user_id,subject_name,question_set_id,obtained_marks,total_marks) values(?,?,?,?,?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, saveResultObject.getUserId());
        ps.setString(2,saveResultObject.getSubjectName());
        ps.setString(3,saveResultObject.getQuestionSetId());
        ps.setString(4,saveResultObject.getObtainedMarks());
        ps.setString(5,saveResultObject.getTotalMarks());

        ps.executeUpdate();
    }
}
