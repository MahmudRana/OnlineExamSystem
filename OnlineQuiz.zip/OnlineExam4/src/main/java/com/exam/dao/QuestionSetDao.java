package com.exam.dao;

import com.exam.DbConnect;
import com.exam.Model.QuestionInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class QuestionSetDao {

    public void insertQuestionSetWithQuestionsInDb(int questionSetIndex, QuestionInfo questionInfo) throws SQLException {
        Connection myConn = null;
        DbConnect dbConnect = new DbConnect();
        myConn = dbConnect.getDataBaseConnection();
        String insertSQL = "insert into question_set(question_set_id,question_id) values(?,?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, String.valueOf(questionSetIndex));
        ps.setString(2,questionInfo.getQuestionDetails());

        ps.executeUpdate();
    }
}
