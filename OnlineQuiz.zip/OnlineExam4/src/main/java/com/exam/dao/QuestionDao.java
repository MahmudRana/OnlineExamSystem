package com.exam.dao;

import com.exam.DbConnect;
import com.exam.Model.QuestionInfo;

import java.sql.*;
import java.util.ArrayList;

public class QuestionDao {

    public void inserQuestionIntoDb(int questionIdIndex, QuestionInfo questionInfo) throws SQLException {
        Connection myConn = null;
        DbConnect dbConnect = new DbConnect();
        myConn = dbConnect.getDataBaseConnection();
        String insertSQL = "insert into question(question_id,question_details,question_type) values(?,?,?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, String.valueOf(questionIdIndex));
        ps.setString(2,questionInfo.getQuestionDetails());
        ps.setString(3,questionInfo.getQuestionType());

        ps.executeUpdate();

    }

    public void insertAnswerIntoDb(int questionIdIndex, QuestionInfo questionInfo) throws SQLException {
        Connection myConn = null;
        DbConnect dbConnect = new DbConnect();
        myConn = dbConnect.getDataBaseConnection();
        String insertSQL = "insert into answer(question_id,question_details,answer) values(?,?,?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, String.valueOf(questionIdIndex));
        ps.setString(2,questionInfo.getQuestionDetails());
        ps.setString(3,questionInfo.getAnswer());

        ps.executeUpdate();

    }

    public void insertQuestionIntoQuestionSet(int questionSetIndex) throws SQLException {
        Connection myConn = null;
        DbConnect dbConnect = new DbConnect();
        myConn = dbConnect.getDataBaseConnection();
        String insertSQL = "insert into question_set(question_set_id) values(?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, String.valueOf(questionSetIndex));

        ps.executeUpdate();
    }

    public void insertOptionsintoDb(int questionIdIndex, QuestionInfo questionInfo) throws SQLException {
        Connection myConn = null;
        DbConnect dbConnect = new DbConnect();
        myConn = dbConnect.getDataBaseConnection();
        String insertSQL = "insert into options(question_id,option_1,option_2,option_3,option_4) values(?,?,?,?,?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, String.valueOf(questionIdIndex));
        ps.setString(2,questionInfo.getOption1());
        ps.setString(3,questionInfo.getOption2());
        ps.setString(4,questionInfo.getOption3());
        ps.setString(5,questionInfo.getOption4());

        ps.executeUpdate();

    }

    public void insertQuestionSetAndSubjectIntoDb(String subjectName) throws SQLException {
        Connection myConn = null;
        DbConnect dbConnect = new DbConnect();
        try {
            myConn = dbConnect.getDataBaseConnection();
        } catch (SQLException e) {
            System.out.println("DB connection error");
        }
        String insertSQL = "insert into subject(subject_name) values(?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, subjectName);

        try {
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Insert into subject table failed !!");
        }

    }

    public int getLastQuestionSet() throws SQLException {

        int index = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT question_set_id FROM subject ORDER BY question_set_id DESC LIMIT 1";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            index = resultSet.getInt("question_set_id");

        }
        return index;
    }

    public int getLastQuestionId() throws SQLException {

        int index = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT question_id FROM question_set ORDER BY question_id DESC LIMIT 1";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            index = resultSet.getInt("question_id");

        }
        return index;
    }
}
