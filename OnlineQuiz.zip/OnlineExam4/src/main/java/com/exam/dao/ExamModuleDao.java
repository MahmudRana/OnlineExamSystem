package com.exam.dao;

import com.exam.DbConnect;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ExamModuleDao {

    public ArrayList<String> getAllSubjectFromDb() throws SQLException {

        ArrayList<String>subjectList = new ArrayList<>();
        int subjectCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT DISTINCT subject_name FROM Subject";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String name = resultSet.getString("subject_name");
            subjectList.add(name);
        }
        return subjectList;
    }
}
