package com.exam.dao;

import com.exam.DbConnect;

import java.sql.*;

public class AdminDao {

    Statement myStmt = null;
    ResultSet myRs = null;

    String dbAdminId;
    String dbPassword;

    public boolean searchAdminByIdAndPass(String id, String pass, Connection connection) throws SQLException {

        boolean login = false;
        connection = DbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT * FROM admin where login_id='"+id+"' and password='"+pass+"'";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        System.out.println(resultSet.getFetchSize());
        while (resultSet.next()){
            System.out.println(resultSet.getRow());
            login = true;
        }

        return login;
    }
}
