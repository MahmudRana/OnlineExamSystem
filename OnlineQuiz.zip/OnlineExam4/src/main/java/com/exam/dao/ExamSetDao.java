package com.exam.dao;

import com.exam.DbConnect;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ExamSetDao {
    public ArrayList<String> getAllQuestionSetFromDb(String subjectName) throws SQLException {

        ArrayList<String> questionsetList = new ArrayList<>();
        int questionsetCount = 0;
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT DISTINCT question_set_id FROM subject WHERE subject_name='"+subjectName+"'";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while(resultSet.next()) {

            String name = resultSet.getString("question_set_id");
            questionsetList.add(name);

        }
        return  questionsetList;
    }

    public String getSubjectNameByQuestionSetIdFromDb(String questionSetId) throws SQLException {


        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT subject_name FROM subject WHERE question_set_id="+questionSetId+"";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        String name = null;
        while(resultSet.next()) {
            name = resultSet.getString("subject_name");
        }
        return  name;
    }
}
