package com.exam.dao;

import com.exam.DbConnect;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class CalculateResultDao {
    public boolean checkAnswer(String questionId, String userAnswer) throws SQLException {

        boolean found = false;
        Connection connection = null;
        connection = DbConnect.getDataBaseConnection();
        Statement statement = connection.createStatement();
        String query = "SELECT * FROM answer where question_id="+questionId+" and answer='"+userAnswer+"'";
        System.out.println("MY QUERY : "+query);
        ResultSet resultSet = statement.executeQuery(query);
        while (resultSet.next()){
            System.out.println(resultSet.getRow());
            found = true;
        }


        return found;
    }


    public ArrayList<String> getAnswerList(ArrayList<String> questionIdList) throws SQLException {

        ArrayList<String>answerList =new ArrayList<>();
        int questionCount = questionIdList.size();
        for(int i=0;i<questionCount;i++){
            DbConnect dbConnect = new DbConnect();
            Connection connection = dbConnect.getDataBaseConnection();
            Statement statement = connection.createStatement();
            String questionId = questionIdList.get(i);
            String query = "SELECT answer FROM answer WHERE question_id="+questionId+"";
            System.out.println("MY QUERY : "+query);
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()) {

                String name = resultSet.getString("answer");
                answerList.add(name);

            }

        }

        return  answerList;
    }
}
