package com.exam.Controller;

import com.exam.service.AdminLoginService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class AdminLoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect(  "AdminLogin.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String loginId = req.getParameter("login_id");
        String password = req.getParameter("password");


       AdminLoginService adminLoginService = new AdminLoginService();
        try {
            if(adminLoginService.isLoginSuccessful(loginId,password)){
                resp.sendRedirect("QuestionUploadPageDynamic.jsp");
            }else{
                resp.sendRedirect("error.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
}
