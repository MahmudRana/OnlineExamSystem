package com.exam.Controller;

import com.exam.DbConnect;
import com.exam.Model.User;
import com.exam.dao.UserDao;
import com.exam.service.UserSignUpService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class UserSignUpServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        boolean isUserExists = false;

        String user_id = req.getParameter("user_id");
        String password = req.getParameter("password");
        String username = req.getParameter("username");
        String address = req.getParameter("address");
        String city = req.getParameter("city");
        String phonenumber = req.getParameter("phonenumber");
        String email = req.getParameter("email");

        User user = new User();

        user.setUser_id(user_id);
        user.setPassword(password);
        user.setUsername(username);
        user.setAddress(address);
        user.setCity(city);
        user.setPhonenumber(phonenumber);
        user.setEmail(email);

        DbConnect dbConnect = new DbConnect();
        Connection connection = null;
        try {
            connection = dbConnect.getDataBaseConnection();
        } catch (SQLException e) {
            System.out.println("DbConnection Error" + e);
        }

        UserSignUpService userSignUpService = new UserSignUpService();
        //check user existance
        UserDao userDao = new UserDao();
        try {
            isUserExists = userDao.searchUserById(user_id);
        } catch (SQLException e) {
            System.out.println("Duplicate USer Test Error in signup");
        }
        if(isUserExists){

            String message = "Duplicate User Id. PLease try with another id";
            req.setAttribute("message",message);
            req.getRequestDispatcher("ErrorMessage.jsp").forward(req,resp);

        }
        try {
             userSignUpService.insertIntoUser(user,connection);
        } catch (SQLException e) {
            System.out.println("SignUp error" + e);
        }

        resp.sendRedirect("welcome.jsp");
    }
}
