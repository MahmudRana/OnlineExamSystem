package com.exam.Controller;

import com.exam.service.UserLoginService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class UserLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userId = req.getParameter("user_id");
        String password = req.getParameter("password");

        UserLoginService userLoginService = new UserLoginService();
        try {
            if(userLoginService.isLoginSuccessful(userId,password)){
                req.setAttribute("user_id",userId);
                req.getRequestDispatcher("Subject.jsp").forward(req,resp);
            }else{
                resp.sendRedirect("error.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
