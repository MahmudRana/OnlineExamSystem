package com.exam.Controller;

import com.exam.service.ExamModuleService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserExamModuleServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userId = req.getParameter("user_id");
        System.out.println("User id  : " + userId );

        String buttonName = req.getParameter("button");
        if(buttonName.equals("Take A Quiz")){
        ArrayList<String>messageList = new ArrayList<>();
        ExamModuleService examModuleService = new ExamModuleService();
        try {
          messageList = examModuleService.getAllSubject();


        } catch (SQLException e) {
            System.out.println("Subject Fetching Error");
        }
        int subjectListSize ;
        subjectListSize = messageList.size();
        String[]messages = new String[subjectListSize];
        for(int i=0;i<messageList.size();i++){
            messages[i] = messageList.get(i);
        }
        req.setAttribute("myname",messages);
            req.setAttribute("user_id",userId);
        req.getRequestDispatcher("ExamModule.jsp").forward(req, resp);

    }
    //else if(buttonName.equals("Result")){

            //req.setAttribute("user_id",userId);
        }
}

