package com.exam.Controller;

import com.exam.Model.SaveResultObject;
import com.exam.service.CalculateResultService;
import com.exam.service.ExamSetService;
import com.exam.service.SaveResultService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;


public class CalculateResult extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        int marks = 0;
        String[] userAnswers = null;
        if(req.getParameterValues("option") !=null) {
            userAnswers = req.getParameterValues("option");
        }
        String[] questionId = req.getParameterValues("question_id");


        String userId = req.getParameter("user_id");
        String questionSetId = req.getParameter("question_set_id");
        System.out.println("User Id in Calculate Result : " + userId);
        System.out.println("Question Set Id in Calculate Result : " + questionSetId);

        String message = null;

        //empty answer checck
        if(userAnswers==null){
            message = "You Haven't filled any of the Answers";
            req.setAttribute("message",message);
            req.getRequestDispatcher("ErrorMessage.jsp").forward(req,resp);
        }
        else if(userAnswers.length<questionId.length){
            message = "You Haven't filled all the Answers. Please Go Back and fill all of them to see the Result";
            req.setAttribute("message",message);
            req.getRequestDispatcher("ErrorMessage.jsp").forward(req,resp);
        }
        else if(userAnswers.length>questionId.length){
            message = "Please, Select just one checkbox for each answer";
            req.setAttribute("message",message);
            req.getRequestDispatcher("ErrorMessage.jsp").forward(req,resp);
        }
        int totalquestions = questionId.length;

        CalculateResultService calculateResultService = new CalculateResultService();
        for(int i=0;i<questionId.length;i++){

            try {
                if (calculateResultService.checkAnswer(questionId[i],userAnswers[i])){
                    marks ++;
                }
            } catch (SQLException e) {
                System.out.println("Answer Fetching error");
            }

        }

        //result save into DB
        SaveResultService saveResultService = new SaveResultService();
        ExamSetService examSetService = new ExamSetService();
        SaveResultObject saveResultObject = new SaveResultObject();
        saveResultObject.setUserId(userId);
        saveResultObject.setQuestionSetId(questionSetId);
        try {
            saveResultObject.setSubjectName(examSetService.getSubjectNameByQuestionSetId(questionSetId));
        } catch (SQLException e) {
            System.out.println("Error fetching Subject Name corresponded to question set id");
        }
        saveResultObject.setObtainedMarks(String.valueOf(marks));
        saveResultObject.setTotalMarks(String.valueOf(totalquestions));

        try {
            saveResultService.saveResult(saveResultObject);
        } catch (SQLException e) {
            System.out.println("Error in Saving Result");
        }

        // redirect work
        System.out.println("marks : " + marks + "total : " + totalquestions);
        req.setAttribute("marks",String.valueOf(marks));
        req.setAttribute("total_marks", String.valueOf(totalquestions) );
        req.setAttribute("user_id",userId);
        req.setAttribute("question_set_id",questionSetId);
        try {
            req.setAttribute("subject_name",examSetService.getSubjectNameByQuestionSetId(questionSetId));
        } catch (SQLException e) {
            System.out.println("sending subject name error");
        }
        req.getRequestDispatcher("Result.jsp").forward(req, resp);


    }
}
