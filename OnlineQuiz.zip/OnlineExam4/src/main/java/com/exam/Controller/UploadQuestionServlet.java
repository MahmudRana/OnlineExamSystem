package com.exam.Controller;

import com.exam.Model.QuestionInfo;
import com.exam.dao.QuestionDao;
import com.exam.service.UploadQuestionService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;

public class UploadQuestionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String[] questions = req.getParameterValues("question");
        String[] option1s = req.getParameterValues("option_1");
        String[] option2s = req.getParameterValues("option_2");
        String[] option3s = req.getParameterValues("option_3");
        String[] option4s = req.getParameterValues("option_4");
        String[] answers = req.getParameterValues("answer");
        String subjectName = req.getParameter("subject_name");

        //insert question set
        QuestionDao questionDao = new QuestionDao();
        try {
            questionDao.insertQuestionSetAndSubjectIntoDb(subjectName);
        } catch (SQLException e) {
            System.out.println("Question Set insert Error");
        }

        int questionSetIndex = 0;
        try {
             questionSetIndex = questionDao.getLastQuestionSet();
        } catch (SQLException e) {
            System.out.println("Question Set index fetching error");
        }

        int questionNumber = questions.length;
        for (int i=0;i<questionNumber;i++){
            QuestionInfo questionInfo = new QuestionInfo();
            questionInfo.setQuestionDetails(questions[i]);
            questionInfo.setOption1(option1s[i]);
            questionInfo.setOption2(option2s[i]);
            questionInfo.setOption3(option3s[i]);
            questionInfo.setOption4(option4s[i]);
            questionInfo.setAnswer(answers[i]);
            questionInfo.setSubjectName(subjectName);
            questionInfo.setQuestionSetIndex(questionSetIndex);

            UploadQuestionService uploadQuestionService = new UploadQuestionService();
            try {
                uploadQuestionService.insertQuestionInDb(questionInfo);
            } catch (SQLException e) {
                System.out.println("Question Upload failed");
            }
        }
    }
}
