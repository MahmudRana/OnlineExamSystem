package com.exam.Controller;

import com.exam.service.ExamSetService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class QuestionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        String subjectName = req.getParameter("button");
        String userId = req.getParameter("user_id");
        System.out.println("User id in Question set fetch : " + userId);

        ArrayList<String> messageList = new ArrayList<>();
        ExamSetService examSetService = new ExamSetService();
        try {
            messageList = examSetService.getAllQuestionSet(subjectName);


        } catch (SQLException e) {
            System.out.println("Question Set Fetching Error");
        }
        int questionSetSize ;
        questionSetSize = messageList.size();
        String[]messages = new String[questionSetSize];
        for(int i=0;i<messageList.size();i++){
            messages[i] = messageList.get(i);
        }
        req.setAttribute("myname",messages);
        req.setAttribute("user_id",userId);
        req.getRequestDispatcher("ExamSet.jsp").forward(req, resp);

    }


}
