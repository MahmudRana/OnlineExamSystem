package com.exam.Controller;

import com.exam.Model.MultipleOptions;
import com.exam.service.ExamSetService;
import com.exam.service.ShowQuestionService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ShowQuestionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String questionSetId = req.getParameter("button");
        String userId = req.getParameter("user_id");
        System.out.println("User id in Show question : " + userId);

        ArrayList<String> questionIdList = new ArrayList<>();
        ArrayList<String> questionList = new ArrayList<>();
        ArrayList<String> option1List = new ArrayList<>();
        ArrayList<String> option2List = new ArrayList<>();
        ArrayList<String> option3List = new ArrayList<>();
        ArrayList<String> option4List = new ArrayList<>();

        ShowQuestionService showQuestionService = new ShowQuestionService();

        try {
            questionIdList = showQuestionService.getQuestionId(questionSetId);
            questionList = showQuestionService.getQuestionDetails(questionSetId);
            option1List = showQuestionService.getOption1(questionSetId);
            option2List = showQuestionService.getOption2(questionSetId);
            option3List = showQuestionService.getOption3(questionSetId);
            option4List = showQuestionService.getOption4(questionSetId);
        } catch (SQLException e) {
            System.out.println("Question details Fetching error");
        }

        int questionSetSize ;
        questionSetSize = questionList.size();
        String[]questionDetails = new String[questionSetSize];

        ArrayList<MultipleOptions> multipleOptionsList = new ArrayList<>();
        for(int i=0;i<questionList.size();i++){
            MultipleOptions multipleOptions = new MultipleOptions();

            multipleOptions.setQuestionId(questionIdList.get(i));
            multipleOptions.setQuestiondetails(questionList.get(i));
            multipleOptions.setOption1(option1List.get(i));
            multipleOptions.setOption2(option2List.get(i));
            multipleOptions.setOption3(option3List.get(i));
            multipleOptions.setOption4(option4List.get(i));

            multipleOptionsList.add(multipleOptions);
        }
        req.setAttribute("optionsList",multipleOptionsList);
        req.setAttribute("user_id",userId);
        req.setAttribute("question_set_id",questionSetId);
        req.getRequestDispatcher("ShowOptions.jsp").forward(req, resp);

    }
}
