package com.exam.Model;

public class QuestionSet {
    private int questionSetId;
    private int questionId;
    private int subjectId;
}
