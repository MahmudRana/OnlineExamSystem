package com.exam.Model;

public class Question {
    private int questionId;
    private String questionDetails;
    private String questionType;
}
