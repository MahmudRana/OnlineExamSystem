package com.exam.Model;

public class Subject {
    private int subjectId;
    private String name;
}
