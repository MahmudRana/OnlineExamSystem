package com.exam.Model;

public class Answer {
    private int questionId;
    private String answer;
}
