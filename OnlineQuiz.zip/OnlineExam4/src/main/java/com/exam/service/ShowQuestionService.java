package com.exam.service;

import com.exam.dao.ExamSetDao;
import com.exam.dao.ShowQuestionDao;

import java.sql.SQLException;
import java.util.ArrayList;


public class ShowQuestionService {
    public ArrayList<String> getQuestionDetails(String questionSetId) throws SQLException {
        ShowQuestionDao showQuestionDao = new ShowQuestionDao();
        ArrayList<String> questionDetailsList = new ArrayList<>();
        questionDetailsList = showQuestionDao.getAllQuestionDetailsFromDB(questionSetId);
        return questionDetailsList;
    }

    public ArrayList<String> getOption1(String questionSetId) throws SQLException {
        ShowQuestionDao showQuestionDao = new ShowQuestionDao();
        ArrayList<String> optionList = new ArrayList<>();
        optionList = showQuestionDao.getAllOption1FromDb(questionSetId);
        return optionList;
    }

    public ArrayList<String> getOption2(String questionSetId) throws SQLException {
        ShowQuestionDao showQuestionDao = new ShowQuestionDao();
        ArrayList<String> optionList = new ArrayList<>();
        optionList = showQuestionDao.getAllOption2FromDb(questionSetId);
        return optionList;
    }

    public ArrayList<String> getOption3(String questionSetId) throws SQLException {
        ShowQuestionDao showQuestionDao = new ShowQuestionDao();
        ArrayList<String> optionList = new ArrayList<>();
        optionList = showQuestionDao.getAllOption3FromDb(questionSetId);
        return optionList;
    }

    public ArrayList<String> getOption4(String questionSetId) throws SQLException {
        ShowQuestionDao showQuestionDao = new ShowQuestionDao();
        ArrayList<String> optionList = new ArrayList<>();
        optionList = showQuestionDao.getAllOption4FromDb(questionSetId);
        return optionList;
    }

    public ArrayList<String> getQuestionId(String questionSetId) throws SQLException {
        ShowQuestionDao showQuestionDao = new ShowQuestionDao();
        ArrayList<String> optionList = new ArrayList<>();
        optionList = showQuestionDao.getAllQuestionIdFromDb(questionSetId);
        return optionList;
    }
}
