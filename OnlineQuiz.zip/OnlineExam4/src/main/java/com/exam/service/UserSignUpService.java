package com.exam.service;

import com.exam.Model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserSignUpService {

    public static void insertIntoUser(User user, Connection myConn) throws SQLException {

        String insertSQL = "insert into user(user_id,password,username,address,city,phonenumber,email) values(?,?,?,?,?,?,?)";
        PreparedStatement ps = myConn.prepareStatement(insertSQL);
        ps.setString(1, String.valueOf(user.getUser_id()));
        ps.setString(2,user.getPassword());
        ps.setString(3,user.getUsername());
        ps.setString(4,user.getAddress());
        ps.setString(5,user.getCity());
        ps.setString(6, String.valueOf(user.getPhonenumber()));
        ps.setString(7,user.getEmail());
        ps.executeUpdate();

    }
}
