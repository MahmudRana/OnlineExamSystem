package com.exam.service;

import com.exam.DbConnect;
import com.exam.dao.UserDao;

import java.sql.Connection;
import java.sql.SQLException;

public class UserLoginService {
    public boolean isLoginSuccessful(String userId, String password) throws SQLException {
        UserDao userDao = new UserDao();
        return userDao.searchUserByIdAndPass(userId,password);
    }
}
