package com.exam.service;

import com.exam.Model.QuestionInfo;
import com.exam.dao.QuestionDao;
import com.exam.dao.QuestionSetDao;

import java.sql.SQLException;

public class UploadQuestionService {

    public void insertQuestionInDb(QuestionInfo questionInfo) throws SQLException {

        QuestionDao questionDao = new QuestionDao();

        questionDao.insertQuestionIntoQuestionSet(questionInfo.getQuestionSetIndex());

        int questionIdIndex = questionDao.getLastQuestionId();

        questionDao.inserQuestionIntoDb(questionIdIndex,questionInfo);
        questionDao.insertAnswerIntoDb(questionIdIndex,questionInfo);

        questionDao.insertOptionsintoDb(questionIdIndex,questionInfo);
    }

}
