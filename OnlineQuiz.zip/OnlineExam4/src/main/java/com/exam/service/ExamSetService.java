package com.exam.service;

import com.exam.dao.ExamSetDao;

import java.sql.SQLException;
import java.util.ArrayList;

public class ExamSetService {
    public ArrayList<String> getAllQuestionSet(String subjectName) throws SQLException {
        ExamSetDao examSetDao = new ExamSetDao();
        ArrayList<String> questionsetList = new ArrayList<>();
        questionsetList = examSetDao.getAllQuestionSetFromDb(subjectName);
        return questionsetList;
    }

    public String getSubjectNameByQuestionSetId(String questionSetId) throws SQLException {
        ExamSetDao examSetDao = new ExamSetDao();
        String subjectName = examSetDao.getSubjectNameByQuestionSetIdFromDb(questionSetId);
        return subjectName;
    }
}
