package com.exam.service;

import com.exam.Model.SaveResultObject;
import com.exam.dao.SaveResultDao;

import java.sql.SQLException;

public class SaveResultService {
    public void saveResult(SaveResultObject saveResultObject) throws SQLException {
        SaveResultDao saveResultDao = new SaveResultDao();
        saveResultDao.saveResult(saveResultObject);
    }
}
