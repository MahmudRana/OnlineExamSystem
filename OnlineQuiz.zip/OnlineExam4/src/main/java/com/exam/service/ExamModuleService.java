package com.exam.service;

import com.exam.dao.ExamModuleDao;

import java.sql.SQLException;
import java.util.ArrayList;

public class ExamModuleService {


    public ArrayList<String> getAllSubject() throws SQLException {
        ExamModuleDao examModuleDao = new ExamModuleDao();
        ArrayList<String> subjectList = new ArrayList<>();
        subjectList = examModuleDao.getAllSubjectFromDb();
        return subjectList;
    }
}
