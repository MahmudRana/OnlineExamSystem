package com.exam.service;

import com.exam.DbConnect;
import com.exam.dao.AdminDao;

import java.sql.Connection;
import java.sql.SQLException;

public class AdminLoginService {
    public boolean isLoginSuccessful(String loginId, String password) throws SQLException {
        DbConnect dbConnect = new DbConnect();
        Connection connection = null;
        connection = dbConnect.getDataBaseConnection();

        AdminDao adminDao = new AdminDao();
        return adminDao.searchAdminByIdAndPass(loginId,password,connection);
    }
}