package com.exam.service;

import com.exam.Controller.CalculateResult;
import com.exam.dao.CalculateResultDao;

import java.sql.SQLException;

public class CalculateResultService {

    public boolean checkAnswer(String questionId, String userAnswer) throws SQLException {
        CalculateResultDao calculateResultDao = new CalculateResultDao();
        return calculateResultDao.checkAnswer(questionId,userAnswer);
    }
}
